/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejerciciocuatro;

/**
 *
 * @author juanj.hermon
 */
public class Principal {

    public static void main(String[] args) {
        Hilo hilo1 = new Hilo(1000, 1, "Hilo 1");
        Hilo hilo2 = new Hilo(2000, 1001, "Hilo 2");

        Thread th1 = new Thread(hilo1);
        Thread th2 = new Thread(hilo2);

        th1.start();
        th2.start();
        
        try {
            th1.join();
            th2.join();
        } catch (InterruptedException e) {
            System.out.println("Hilo interrumpido");
        }
    }

}
