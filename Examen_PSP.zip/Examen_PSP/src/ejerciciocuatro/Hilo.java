/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejerciciocuatro;

/**
 *
 * @author juanj.hermon
 */
public class Hilo implements Runnable {

    private int max;
    private int min;
    private String tarea;

    public Hilo(int max, int min, String tarea) {
        this.max = max;
        this.min = min;
        this.tarea = tarea;
    }

    @Override
    public void run() {
        System.out.println("Comenzando " + tarea);
        for (int i = min; i <= max; i++) {
            if(esPrimo(i)){
                System.out.print(i + "\n");
            }
                
            
        }
        System.out.println("Terminado " + tarea);

    }

    private boolean esPrimo(int numero) {

        if (numero <= 1) {
            return false;
        }
        for (int i = 2; i < numero; i++) {
            if (numero % i == 0) {
                return false;
            }
        }

        return true;
    }
}
