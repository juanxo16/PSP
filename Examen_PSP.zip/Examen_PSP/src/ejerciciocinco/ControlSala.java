/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejerciciocinco;

/**
 *
 * @author juanj.hermon
 */
public class ControlSala {
    
     private final int capacidad;
    private int numPersonas = 0;

    public ControlSala(int capacidad) {
        this.capacidad = capacidad;
    }
    
    
    
    public synchronized void entraPersona() throws InterruptedException{
        if(numPersonas >= capacidad){
            System.out.println("No hay plazas la sala");
            wait();
        }
        Thread.sleep(300);
        numPersonas++;
    }
    
    public synchronized void salePersona(){

        numPersonas--;
        notifyAll();
    }
}
