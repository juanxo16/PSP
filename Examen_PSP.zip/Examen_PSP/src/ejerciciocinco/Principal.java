/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejerciciocinco;

import java.util.ArrayList;

/**
 *
 * @author juanj.hermon
 */
public class Principal {
    
     public static void main(String[] args) throws InterruptedException {

        int i;

        ControlSala contrlsala = new ControlSala(60);
        ArrayList<Thread> personas = new ArrayList<>();

        for (i = 0; i < 20; i++) {

            personas.add(new Thread(new Persona("Persona " + i, contrlsala)));
        }

        for (Thread h : personas) {
            h.start();
            Thread.sleep(1000);
        }

        try {
            for (Thread h : personas) {
                h.join();
            }
        } catch (Exception e) {

        }
    }
}
