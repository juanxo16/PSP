/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejerciciocinco;

/**
 *
 * @author juanj.hermon
 */
public class Persona extends Thread {

    private String nombre;
    private ControlSala sala;

    public Persona(String nombre, ControlSala sala) {
        this.nombre = nombre;
        this.sala = sala;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public ControlSala getSala() {
        return sala;
    }

    public void setSala(ControlSala sala) {
        this.sala = sala;
    }


    @Override
    public void run() {
        
        try{
           sala.entraPersona();
            
            System.out.println("La persona " +nombre+ " entra a la sala");
            
            Thread.sleep(10000);
            
            sala.salePersona();
            
            System.out.println("La persona " +nombre+ " sale de la sala");
        }catch(InterruptedException ex){
            
        }
    }
    
    

   
}
