/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejerciciotres;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Scanner;

/**
 *
 * @author juanj.hermon
 */
public class Ejercicio_3 {
    static Scanner sc = new Scanner(System.in);
    static Runtime r = Runtime.getRuntime();
    static ProcessBuilder pb = new ProcessBuilder();
    static InputStream is;
    static InputStreamReader isr;
    static BufferedReader br;
    
    
    
    public static void main(String[] args) throws InterruptedException {
        System.out.println("-------------");
        System.out.println("1 - Comando nslookup");
        System.out.println("2 - Programa python");
        System.out.println("-------------");
        System.out.println("Elige la opcion que quieres");
        int opcion = sc.nextInt();
        
        Process proceso1, proceso2;
        int exitCode;
        
        if (opcion == 1){
            try{
            String comando1 = "C:\\WINDOWS\\system32\\nslookup www.google.es";
            System.out.println("Lanzando el nslookup");
            proceso1 = r.exec(comando1);
            System.out.println("Esperando a que termine la ejecución del nslookup");
            exitCode = proceso1.waitFor();
            
            if(exitCode==0){
                System.out.println("nslookup se lanzó con éxito");
                is = proceso1.getInputStream();
                isr = new InputStreamReader(is);
                br = new BufferedReader(isr);
            }
            else{
                System.out.println("Error en la ejecución de nslookup");
                is = proceso1.getInputStream();
                isr = new InputStreamReader(is);
                br = new BufferedReader(isr);
            }
            
            String linea  = br.readLine();
            while(linea != null){
                System.out.println(linea);
                linea = br.readLine();
            }
            br.close();
            isr.close();
            is.close();
            
        }
        catch(IOException | InterruptedException e){
            System.out.println("Error: " + e.getMessage());
        }
        }
        else if(opcion == 2){
            try {

            String cad1 = "C:\\Program Files\\Python311\\python.exe";
            String cad2 = "C:\\Users\\juanj.hermon\\Downloads\\tablamultiplicar.py";

            pb.command(cad1, cad2);
            proceso2 = pb.start();
            exitCode = proceso2.waitFor();

            if (exitCode == 0) {
                System.out.println("El python se lanzo con éxito");
            } else {
                System.out.println("Error al lanzar el python");
            }
            is = proceso2.getInputStream();
            isr = new InputStreamReader(is);
            br = new BufferedReader(isr);

            String linea;

            do {
                linea = br.readLine();
                if (linea != null) {
                    System.out.println(linea);
                }

            } while (linea != null);

            br.close();
            isr.close();
            is.close();

        } catch (IOException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
    
        }
        else{
            System.out.println("Opcion mal seleccionada");
        }
    }
    
}
